package it.ssm.controller;


import com.github.pagehelper.PageHelper;
import it.ssm.dao.UserinfoDao;
import it.ssm.domain.Userinfo;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.servlet.ServletContext;
import java.util.List;

@Controller
@RequestMapping("/index")
public class index {

    @ResponseBody
    @RequestMapping("/show")
    public String show(){
        ServletContext servletContext = ContextLoader.getCurrentWebApplicationContext().getServletContext();
        WebApplicationContext app = WebApplicationContextUtils.getWebApplicationContext(servletContext);
        UserinfoDao bean = app.getBean(UserinfoDao.class);
        PageHelper.startPage(1,1);
        List<Userinfo> users = bean.getUsers();
        System.out.println(users);
        return "hello world";
    }
}
